"use client";

import { useState } from "react";

const categories = ["EBT", "GRK/Karbon", "TKDN", "Lingkungan", "Konservasi Energi", "Biomassa", "SOP"];
const statuses = ["Berlaku", "Dicabut", "Diubah", "Perlu Review"];
const relevance = ["Sangat Tinggi", "Tinggi", "Sedang", "Rendah"];

export default function AdminUploadForm() {
  const [message, setMessage] = useState<string | null>(null);
  const [isError, setIsError] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setMessage(null);
    setIsError(false);

    const form = event.currentTarget;
    const formData = new FormData(form);
    const adminPassword = formData.get("admin_password")?.toString() || "";
    formData.delete("admin_password");

    try {
      const response = await fetch("/api/documents", {
        method: "POST",
        headers: { "x-admin-password": adminPassword },
        body: formData
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Gagal menyimpan dokumen.");

      setMessage(`Berhasil menyimpan dokumen: ${result.title}`);
      form.reset();
    } catch (error) {
      setIsError(true);
      setMessage(error instanceof Error ? error.message : "Terjadi kesalahan.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form className="card" onSubmit={handleSubmit}>
      {message ? <div className={`notice ${isError ? "error" : ""}`}>{message}</div> : null}

      <div className="form-grid">
        <div>
          <label>Password admin</label>
          <input className="input" type="password" name="admin_password" required placeholder="Sesuai ADMIN_PASSWORD di .env.local" />
        </div>
        <div>
          <label>Tipe dokumen</label>
          <select name="document_type" required defaultValue="regulasi">
            <option value="regulasi">Regulasi</option>
            <option value="sop">SOP</option>
          </select>
        </div>
        <div className="form-row-full">
          <label>Judul dokumen</label>
          <input className="input" name="title" required placeholder="Contoh: Perpres No. 112 Tahun 2022 tentang Percepatan Pengembangan EBT" />
        </div>
        <div>
          <label>Nomor regulasi / kode SOP</label>
          <input className="input" name="regulation_number" placeholder="Contoh: Perpres No. 112 Tahun 2022 / SOP-001" />
        </div>
        <div>
          <label>Tahun</label>
          <input className="input" name="year" type="number" min="1900" max="2100" placeholder="2022" />
        </div>
        <div>
          <label>Instansi penerbit</label>
          <input className="input" name="issuing_body" placeholder="Presiden RI / ESDM / KLHK / Kemenperin" />
        </div>
        <div>
          <label>Kategori</label>
          <select name="category" defaultValue="EBT">
            {categories.map((category) => <option key={category}>{category}</option>)}
          </select>
        </div>
        <div>
          <label>Sub-kategori</label>
          <input className="input" name="sub_category" placeholder="PLTS, Geothermal, Karbon, Audit Energi, dll." />
        </div>
        <div>
          <label>Status</label>
          <select name="status" defaultValue="Berlaku">
            {statuses.map((status) => <option key={status}>{status}</option>)}
          </select>
        </div>
        <div>
          <label>Relevansi SBU</label>
          <select name="sbu_relevance" defaultValue="Tinggi">
            {relevance.map((item) => <option key={item}>{item}</option>)}
          </select>
        </div>
        <div>
          <label>Priority score 1–25</label>
          <input className="input" name="priority_score" type="number" min="1" max="25" placeholder="Contoh: 18" />
        </div>
        <div>
          <label>Tanggal terakhir dicek</label>
          <input className="input" name="last_checked_at" type="date" />
        </div>
        <div>
          <label>PIC update</label>
          <input className="input" name="pic_update" placeholder="Vita" />
        </div>
        <div>
          <label>Link sumber resmi</label>
          <input className="input" name="source_url" type="url" placeholder="https://peraturan.bpk.go.id/..." />
        </div>
        <div className="form-row-full">
          <label>Ringkasan</label>
          <textarea name="summary" placeholder="Ringkasan 2–3 kalimat." />
        </div>
        <div className="form-row-full">
          <label>Kewajiban utama</label>
          <textarea name="key_obligation" placeholder="Kewajiban yang perlu diperhatikan oleh klien/tim." />
        </div>
        <div>
          <label>Pihak terdampak</label>
          <textarea name="impacted_party" placeholder="PLN, IPP, pengembang PLTS, industri, dll." />
        </div>
        <div>
          <label>Layanan terkait</label>
          <textarea name="related_services" placeholder="Kajian EBT, validasi/verifikasi GRK, TKDN, audit energi, dll." />
        </div>
        <div>
          <label>Peluang layanan</label>
          <textarea name="service_opportunity" placeholder="Peluang jasa yang bisa ditawarkan SBU." />
        </div>
        <div>
          <label>Risiko compliance</label>
          <textarea name="compliance_risk" placeholder="Risiko jika klien tidak memenuhi aturan." />
        </div>
        <div className="form-row-full">
          <label>Action point</label>
          <textarea name="action_point" placeholder="Tindakan yang disarankan untuk tim SBU." />
        </div>
        <div className="form-row-full">
          <label>Catatan</label>
          <textarea name="notes" placeholder="Catatan tambahan." />
        </div>
        <div className="form-row-full">
          <label>Upload file PDF</label>
          <input className="input" name="file" type="file" accept="application/pdf" required />
        </div>
      </div>

      <div style={{ marginTop: 18 }}>
        <button className="btn" type="submit" disabled={loading}>{loading ? "Menyimpan..." : "Simpan Dokumen"}</button>
      </div>
    </form>
  );
}
