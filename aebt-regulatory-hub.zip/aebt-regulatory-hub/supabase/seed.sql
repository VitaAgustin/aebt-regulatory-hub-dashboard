-- Optional sample data without files. Useful for testing the UI before upload.
insert into public.documents (
  document_type, title, regulation_number, year, issuing_body, category, sub_category,
  summary, key_obligation, impacted_party, status, related_services, sbu_relevance,
  service_opportunity, compliance_risk, action_point, priority_score, source_url,
  last_checked_at, pic_update
) values
('regulasi', 'Perpres No. 112 Tahun 2022 tentang Percepatan Pengembangan Energi Terbarukan untuk Penyediaan Tenaga Listrik', 'Perpres No. 112 Tahun 2022', 2022, 'Presiden RI', 'EBT', 'Pembangkit listrik EBT',
 'Regulasi tentang percepatan pengembangan pembangkit listrik dari sumber energi terbarukan.',
 'Memahami ketentuan pengembangan pembangkit EBT dan implikasi terhadap proyek kelistrikan.',
 'PLN, IPP, pengembang PLTS/geothermal/biomassa', 'Berlaku', 'Kajian EBT, inspeksi teknis, dokumen lingkungan', 'Tinggi',
 'Dasar penawaran kajian awal, due diligence, dan inspeksi proyek EBT.', 'Risiko salah dasar regulasi pada proposal/kajian.', 'Gunakan sebagai regulatory driver untuk proyek pembangkit EBT.', 18, 'https://peraturan.bpk.go.id/', current_date, 'Vita'),
('sop', 'SOP Pemutakhiran Database Regulasi', 'SOP-001', 2026, 'Internal', 'SOP', 'Pemutakhiran regulasi',
 'SOP untuk memastikan database regulasi diperbarui secara berkala dari sumber resmi.',
 'Admin wajib mengecek sumber resmi, memperbarui status regulasi, dan mencatat update log.',
 'Admin knowledge hub', 'Berlaku', 'Knowledge management', 'Tinggi',
 'Menjaga database tetap valid dan dapat dipertanggungjawabkan.', 'Database menjadi usang jika tidak ada update rutin.', 'Lakukan review minimal 1 kali per bulan.', 16, null, current_date, 'Vita');
