import { NextRequest, NextResponse } from "next/server";
import { getDocument, getSignedFileUrl } from "@/lib/queries";

export const runtime = "nodejs";

export async function GET(_request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const doc = await getDocument(params.id);
    if (!doc.file_path) {
      return NextResponse.json({ error: "File tidak tersedia." }, { status: 404 });
    }

    const signedUrl = await getSignedFileUrl(doc.file_path, 120);
    if (!signedUrl) {
      return NextResponse.json({ error: "Gagal membuat link download." }, { status: 500 });
    }

    return NextResponse.redirect(signedUrl);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Terjadi kesalahan." }, { status: 500 });
  }
}
