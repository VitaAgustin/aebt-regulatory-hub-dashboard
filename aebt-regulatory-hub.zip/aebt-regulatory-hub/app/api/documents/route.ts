import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin, bucketName } from "@/lib/supabaseAdmin";
import { parseNumber, parseText, slugifyFileName } from "@/lib/helpers";

export const runtime = "nodejs";

function assertAdmin(request: NextRequest) {
  const expected = process.env.ADMIN_PASSWORD;
  const received = request.headers.get("x-admin-password");
  if (!expected || received !== expected) {
    throw new Error("Password admin salah atau ADMIN_PASSWORD belum diset.");
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type");
  const q = searchParams.get("q");
  const category = searchParams.get("category");
  const status = searchParams.get("status");

  let query = supabaseAdmin.from("documents").select("*").order("updated_at", { ascending: false });

  if (type === "regulasi" || type === "sop") query = query.eq("document_type", type);
  if (category) query = query.eq("category", category);
  if (status) query = query.eq("status", status);
  if (q) query = query.or(`title.ilike.%${q}%,summary.ilike.%${q}%,related_services.ilike.%${q}%`);

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ data });
}

export async function POST(request: NextRequest) {
  try {
    assertAdmin(request);
    const formData = await request.formData();
    const file = formData.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "File PDF wajib diupload." }, { status: 400 });
    }

    if (file.type !== "application/pdf") {
      return NextResponse.json({ error: "File harus PDF." }, { status: 400 });
    }

    const documentType = parseText(formData.get("document_type")) || "regulasi";
    if (!["regulasi", "sop"].includes(documentType)) {
      return NextResponse.json({ error: "document_type tidak valid." }, { status: 400 });
    }

    const title = parseText(formData.get("title"));
    if (!title) {
      return NextResponse.json({ error: "Judul wajib diisi." }, { status: 400 });
    }

    const year = parseNumber(formData.get("year"));
    const category = parseText(formData.get("category")) || (documentType === "sop" ? "SOP" : "Umum");
    const safeTitle = slugifyFileName(title).slice(0, 90);
    const originalName = slugifyFileName(file.name);
    const timestamp = Date.now();
    const filePath = `${documentType}/${category}/${year || "tanpa-tahun"}_${timestamp}_${safeTitle || originalName}.pdf`;

    const arrayBuffer = await file.arrayBuffer();
    const { error: uploadError } = await supabaseAdmin.storage
      .from(bucketName)
      .upload(filePath, Buffer.from(arrayBuffer), {
        contentType: "application/pdf",
        upsert: false
      });

    if (uploadError) {
      return NextResponse.json({ error: uploadError.message }, { status: 500 });
    }

    const payload = {
      document_type: documentType,
      title,
      regulation_number: parseText(formData.get("regulation_number")),
      year,
      issuing_body: parseText(formData.get("issuing_body")),
      category,
      sub_category: parseText(formData.get("sub_category")),
      summary: parseText(formData.get("summary")),
      key_obligation: parseText(formData.get("key_obligation")),
      impacted_party: parseText(formData.get("impacted_party")),
      status: parseText(formData.get("status")) || "Berlaku",
      related_services: parseText(formData.get("related_services")),
      sbu_relevance: parseText(formData.get("sbu_relevance")),
      service_opportunity: parseText(formData.get("service_opportunity")),
      compliance_risk: parseText(formData.get("compliance_risk")),
      action_point: parseText(formData.get("action_point")),
      priority_score: parseNumber(formData.get("priority_score")),
      source_url: parseText(formData.get("source_url")),
      file_path: filePath,
      file_name: file.name,
      last_checked_at: parseText(formData.get("last_checked_at")),
      pic_update: parseText(formData.get("pic_update")),
      notes: parseText(formData.get("notes"))
    };

    const { data, error } = await supabaseAdmin
      .from("documents")
      .insert(payload)
      .select("id, title")
      .single();

    if (error) {
      await supabaseAdmin.storage.from(bucketName).remove([filePath]);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    await supabaseAdmin.from("update_logs").insert({
      document_id: data.id,
      action_type: "Tambah dokumen",
      change_note: `Menambahkan ${documentType}: ${title}`,
      source_url: payload.source_url,
      pic: payload.pic_update
    });

    return NextResponse.json(data, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Terjadi kesalahan." }, { status: 401 });
  }
}
