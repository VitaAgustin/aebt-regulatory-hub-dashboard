import { getDashboardStats, listDocuments } from "@/lib/queries";
import { getPriorityLabel } from "@/lib/helpers";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const stats = await getDashboardStats();
  const latest = await listDocuments({});
  const latestFive = latest.slice(0, 5);

  return (
    <main className="container">
      <section className="hero">
        <h1>AEBT Regulatory Knowledge Hub</h1>
        <p>
          Web database regulasi, repository file, service mapping, dan SOP pemutakhiran regulasi untuk mendukung kegiatan kajian, proposal, dan knowledge management SBU AEBT.
        </p>
      </section>

      <section className="grid grid-3" style={{ marginBottom: 16 }}>
        <div className="card"><div className="metric">{stats.total}</div><div className="muted">Total dokumen</div></div>
        <div className="card"><div className="metric">{stats.regulations}</div><div className="muted">Regulasi</div></div>
        <div className="card"><div className="metric">{stats.sops}</div><div className="muted">SOP</div></div>
        <div className="card"><div className="metric">{stats.highPriority}</div><div className="muted">Prioritas tinggi</div></div>
        <div className="card"><div className="metric">{stats.needsReview}</div><div className="muted">Perlu review</div></div>
        <div className="card">
          <h3>Kategori</h3>
          {Object.entries(stats.byCategory).length === 0 ? <p className="muted">Belum ada data.</p> : null}
          {Object.entries(stats.byCategory).map(([category, count]) => (
            <div key={category} style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span>{category}</span><strong>{count}</strong>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <div className="detail-header">
          <div>
            <h2>Dokumen terbaru</h2>
            <p className="muted">Lima dokumen terakhir yang ditambahkan atau diperbarui.</p>
          </div>
          <a className="btn" href="/documents">Buka semua dokumen</a>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Judul</th>
                <th>Tipe</th>
                <th>Kategori</th>
                <th>Status</th>
                <th>Prioritas</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              {latestFive.map((doc) => (
                <tr key={doc.id}>
                  <td><strong>{doc.title}</strong><br /><span className="muted">{doc.regulation_number || "-"}</span></td>
                  <td><span className="badge info">{doc.document_type}</span></td>
                  <td>{doc.category || "-"}</td>
                  <td><span className="badge">{doc.status || "-"}</span></td>
                  <td>{getPriorityLabel(doc.priority_score)}</td>
                  <td><a href={`/documents/${doc.id}`}>Detail</a></td>
                </tr>
              ))}
              {latestFive.length === 0 ? (
                <tr><td colSpan={6} className="muted">Belum ada dokumen. Tambahkan dari halaman Admin Upload.</td></tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
