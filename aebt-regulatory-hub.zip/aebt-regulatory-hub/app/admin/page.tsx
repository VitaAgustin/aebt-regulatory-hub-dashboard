import AdminUploadForm from "@/components/AdminUploadForm";

export default function AdminPage() {
  return (
    <main className="container">
      <section className="hero">
        <h1>Admin Upload</h1>
        <p>
          Tambahkan regulasi atau SOP baru. File PDF akan disimpan ke Supabase Storage, sedangkan metadata disimpan di database.
        </p>
      </section>
      <AdminUploadForm />
    </main>
  );
}
