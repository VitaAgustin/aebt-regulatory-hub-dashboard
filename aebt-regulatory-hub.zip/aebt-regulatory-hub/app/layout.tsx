import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AEBT Regulatory Knowledge Hub",
  description: "Database regulasi, file repository, service mapping, dan SOP pemutakhiran regulasi SBU AEBT."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>
        <header className="navbar">
          <a className="brand" href="/">AEBT Regulatory Hub</a>
          <nav className="navlinks">
            <a href="/documents?type=regulasi">Database Regulasi</a>
            <a href="/documents?type=sop">SOP Center</a>
            <a href="/admin">Admin Upload</a>
          </nav>
        </header>
        {children}
      </body>
    </html>
  );
}
