import { listDocuments } from "@/lib/queries";
import { getPriorityLabel, formatDate } from "@/lib/helpers";

export const dynamic = "force-dynamic";

type SearchParams = {
  type?: string;
  q?: string;
  category?: string;
  status?: string;
};

export default async function DocumentsPage({ searchParams }: { searchParams: SearchParams }) {
  const docs = await listDocuments(searchParams);
  const title = searchParams.type === "sop" ? "SOP Center" : searchParams.type === "regulasi" ? "Database Regulasi" : "Semua Dokumen";

  return (
    <main className="container">
      <div className="detail-header" style={{ marginBottom: 18 }}>
        <div>
          <h1>{title}</h1>
          <p className="muted">Cari regulasi atau SOP, buka file PDF, dan unduh dokumen sesuai kebutuhan.</p>
        </div>
        <a className="btn" href="/admin">Tambah Dokumen</a>
      </div>

      <form className="toolbar" action="/documents" method="get">
        <input type="hidden" name="type" value={searchParams.type || ""} />
        <input className="input" name="q" placeholder="Cari judul, ringkasan, layanan..." defaultValue={searchParams.q || ""} />
        <select name="category" defaultValue={searchParams.category || ""}>
          <option value="">Semua kategori</option>
          <option>EBT</option>
          <option>GRK/Karbon</option>
          <option>TKDN</option>
          <option>Lingkungan</option>
          <option>Konservasi Energi</option>
          <option>Biomassa</option>
          <option>SOP</option>
        </select>
        <select name="status" defaultValue={searchParams.status || ""}>
          <option value="">Semua status</option>
          <option>Berlaku</option>
          <option>Dicabut</option>
          <option>Diubah</option>
          <option>Perlu Review</option>
        </select>
        <button className="btn" type="submit">Terapkan Filter</button>
        <a className="btn secondary" href={`/documents${searchParams.type ? `?type=${searchParams.type}` : ""}`}>Reset</a>
      </form>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Dokumen</th>
              <th>Kategori</th>
              <th>Status</th>
              <th>Layanan terkait</th>
              <th>Prioritas</th>
              <th>Terakhir dicek</th>
              <th>File</th>
            </tr>
          </thead>
          <tbody>
            {docs.map((doc) => (
              <tr key={doc.id}>
                <td>
                  <a href={`/documents/${doc.id}`}><strong>{doc.title}</strong></a><br />
                  <span className="muted">{doc.regulation_number || doc.document_type.toUpperCase()}</span>
                </td>
                <td>{doc.category || "-"}</td>
                <td><span className="badge">{doc.status || "-"}</span></td>
                <td>{doc.related_services || "-"}</td>
                <td>{getPriorityLabel(doc.priority_score)}</td>
                <td>{formatDate(doc.last_checked_at)}</td>
                <td>
                  <a href={`/documents/${doc.id}`}>Lihat</a>
                  {doc.file_path ? <> · <a href={`/api/documents/${doc.id}/download`}>Download</a></> : null}
                </td>
              </tr>
            ))}
            {docs.length === 0 ? (
              <tr><td colSpan={7} className="muted">Tidak ada data yang sesuai filter.</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </main>
  );
}
