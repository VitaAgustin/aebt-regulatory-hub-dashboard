import { getDocument, getSignedFileUrl } from "@/lib/queries";
import { formatDate, getPriorityLabel } from "@/lib/helpers";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function DocumentDetailPage({ params }: { params: { id: string } }) {
  let doc;
  try {
    doc = await getDocument(params.id);
  } catch {
    notFound();
  }

  const signedUrl = await getSignedFileUrl(doc.file_path);

  return (
    <main className="container">
      <section className="card" style={{ marginBottom: 16 }}>
        <div className="detail-header">
          <div>
            <span className="badge info">{doc.document_type}</span>
            <h1>{doc.title}</h1>
            <p className="muted">{doc.regulation_number || doc.file_name || "Dokumen internal"}</p>
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {signedUrl ? <a className="btn secondary" href={signedUrl} target="_blank">Buka File</a> : null}
            {doc.file_path ? <a className="btn" href={`/api/documents/${doc.id}/download`}>Download</a> : null}
          </div>
        </div>

        <div className="meta-grid" style={{ marginTop: 18 }}>
          <div className="meta-item"><span className="meta-label">Kategori</span>{doc.category || "-"}</div>
          <div className="meta-item"><span className="meta-label">Sub-kategori</span>{doc.sub_category || "-"}</div>
          <div className="meta-item"><span className="meta-label">Status</span>{doc.status || "-"}</div>
          <div className="meta-item"><span className="meta-label">Relevansi SBU</span>{doc.sbu_relevance || "-"}</div>
          <div className="meta-item"><span className="meta-label">Priority Score</span>{doc.priority_score ?? "-"} / 25 · {getPriorityLabel(doc.priority_score)}</div>
          <div className="meta-item"><span className="meta-label">Terakhir dicek</span>{formatDate(doc.last_checked_at)}</div>
          <div className="meta-item"><span className="meta-label">Instansi penerbit</span>{doc.issuing_body || "-"}</div>
          <div className="meta-item"><span className="meta-label">PIC update</span>{doc.pic_update || "-"}</div>
        </div>
      </section>

      <section className="grid grid-2" style={{ marginBottom: 16 }}>
        <div className="card">
          <h2>Ringkasan</h2>
          <p>{doc.summary || "Belum ada ringkasan."}</p>
          <h3>Kewajiban utama</h3>
          <p>{doc.key_obligation || "-"}</p>
          <h3>Pihak terdampak</h3>
          <p>{doc.impacted_party || "-"}</p>
        </div>

        <div className="card">
          <h2>Service Mapping</h2>
          <h3>Layanan terkait</h3>
          <p>{doc.related_services || "-"}</p>
          <h3>Peluang layanan</h3>
          <p>{doc.service_opportunity || "-"}</p>
          <h3>Risiko compliance</h3>
          <p>{doc.compliance_risk || "-"}</p>
          <h3>Action point</h3>
          <p>{doc.action_point || "-"}</p>
        </div>
      </section>

      <section className="card" style={{ marginBottom: 16 }}>
        <h2>Preview file</h2>
        {signedUrl ? (
          <iframe className="pdf-frame" src={signedUrl} title={doc.title} />
        ) : (
          <p className="muted">Belum ada file yang terhubung untuk dokumen ini.</p>
        )}
      </section>

      <section className="card">
        <h2>Sumber dan catatan</h2>
        <p><strong>Sumber resmi:</strong> {doc.source_url ? <a href={doc.source_url} target="_blank">Buka sumber</a> : "-"}</p>
        <p><strong>Nama file:</strong> {doc.file_name || "-"}</p>
        <p><strong>Catatan:</strong> {doc.notes || "-"}</p>
      </section>
    </main>
  );
}
