import { supabaseAdmin, bucketName } from "./supabaseAdmin";
import type { RegulatoryDocument } from "./types";

export async function listDocuments(params: {
  type?: string;
  q?: string;
  category?: string;
  status?: string;
}) {
  let query = supabaseAdmin
    .from("documents")
    .select("*")
    .order("updated_at", { ascending: false });

  if (params.type === "regulasi" || params.type === "sop") {
    query = query.eq("document_type", params.type);
  }
  if (params.category) query = query.eq("category", params.category);
  if (params.status) query = query.eq("status", params.status);
  if (params.q) {
    const q = `%${params.q}%`;
    query = query.or(`title.ilike.${q},summary.ilike.${q},category.ilike.${q},related_services.ilike.${q}`);
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data || []) as RegulatoryDocument[];
}

export async function getDocument(id: string) {
  const { data, error } = await supabaseAdmin
    .from("documents")
    .select("*")
    .eq("id", id)
    .single();

  if (error) throw error;
  return data as RegulatoryDocument;
}

export async function getSignedFileUrl(filePath: string | null, expiresInSeconds = 3600) {
  if (!filePath) return null;
  const { data, error } = await supabaseAdmin
    .storage
    .from(bucketName)
    .createSignedUrl(filePath, expiresInSeconds);

  if (error) throw error;
  return data.signedUrl;
}

export async function getDashboardStats() {
  const { data, error } = await supabaseAdmin
    .from("documents")
    .select("id, document_type, category, status, priority_score");

  if (error) throw error;
  const rows = data || [];

  const total = rows.length;
  const regulations = rows.filter((row) => row.document_type === "regulasi").length;
  const sops = rows.filter((row) => row.document_type === "sop").length;
  const highPriority = rows.filter((row) => Number(row.priority_score || 0) >= 16).length;
  const needsReview = rows.filter((row) => row.status === "Perlu Review").length;

  const byCategory = rows.reduce<Record<string, number>>((acc, row) => {
    const key = row.category || "Tanpa kategori";
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});

  return { total, regulations, sops, highPriority, needsReview, byCategory };
}
