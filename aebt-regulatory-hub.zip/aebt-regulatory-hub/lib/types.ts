export type DocumentType = "regulasi" | "sop";
export type RegulationStatus = "Berlaku" | "Dicabut" | "Diubah" | "Perlu Review";
export type Relevance = "Sangat Tinggi" | "Tinggi" | "Sedang" | "Rendah";

export type RegulatoryDocument = {
  id: string;
  document_type: DocumentType;
  title: string;
  regulation_number: string | null;
  year: number | null;
  issuing_body: string | null;
  category: string | null;
  sub_category: string | null;
  summary: string | null;
  key_obligation: string | null;
  impacted_party: string | null;
  status: RegulationStatus | null;
  related_services: string | null;
  sbu_relevance: Relevance | null;
  service_opportunity: string | null;
  compliance_risk: string | null;
  action_point: string | null;
  priority_score: number | null;
  source_url: string | null;
  file_path: string | null;
  file_name: string | null;
  last_checked_at: string | null;
  pic_update: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
};

export type UpdateLog = {
  id: string;
  document_id: string | null;
  action_type: string;
  change_note: string | null;
  source_url: string | null;
  pic: string | null;
  created_at: string;
};
