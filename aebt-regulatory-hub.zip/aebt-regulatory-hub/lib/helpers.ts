export function slugifyFileName(input: string) {
  return input
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9.\-_]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "")
    .toLowerCase();
}

export function parseNumber(value: FormDataEntryValue | null) {
  if (!value) return null;
  const number = Number(value.toString());
  return Number.isFinite(number) ? number : null;
}

export function parseText(value: FormDataEntryValue | null) {
  const text = value?.toString().trim();
  return text ? text : null;
}

export function getPriorityLabel(score: number | null | undefined) {
  if (!score) return "Belum dinilai";
  if (score >= 21) return "Sangat Tinggi";
  if (score >= 16) return "Tinggi";
  if (score >= 11) return "Sedang";
  return "Rendah";
}

export function formatDate(dateString: string | null | undefined) {
  if (!dateString) return "-";
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  }).format(new Date(dateString));
}
